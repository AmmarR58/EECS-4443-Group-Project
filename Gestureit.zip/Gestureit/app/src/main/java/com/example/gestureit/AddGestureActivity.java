package com.example.gestureit;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.widget.ArrayAdapter;


public class AddGestureActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "GesturePrefs";
    private EditText etGestureName;
    private Spinner letterSpinner, appSpinner;
    private Button saveButton, clearButton;
    private ArrayList<CustomGesture> gestureList;
    private GraffitiDrawingView drawingView;
    private Map<String, String> letterToAppMap = new HashMap<>();
    private List<String> appPackages = new ArrayList<>();


//    private final String[] graffitiLetters = {"A", "B", "C", "D", "E", "F", "G", "H",
//            "I", "J", "K", "L", "M", "N", "O", "P",
//            "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gesture);

        etGestureName = findViewById(R.id.etGestureName);
        letterSpinner = findViewById(R.id.letterSpinner);
        appSpinner = findViewById(R.id.appSpinner);
        saveButton = findViewById(R.id.saveButton);
        clearButton = findViewById(R.id.clearButton);
        drawingView = findViewById(R.id.drawingView);
        TextView clearContent = findViewById(R.id.clearContent);

        gestureList = new ArrayList<>();

        // Set up button click listeners
        saveButton.setOnClickListener(v -> saveGestureAssignment());
        clearButton.setOnClickListener(v -> drawingView.clearCanvas());
        clearContent.setOnClickListener(v -> clearAllInputs());

        setupSpinners();
        setupButtons();
    }

    private void setupSpinners() {
        // Letter spinner (A-Z)
        String[] letters = new String[26];
        for (int i = 0; i < 26; i++) {
            letters[i] = String.valueOf((char)('A' + i));
        }

        ArrayAdapter<String> letterAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, letters);
        letterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        letterSpinner.setAdapter(letterAdapter);

        // App spinner with installed apps
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
        List<String> appNames = new ArrayList<>();

        for (ResolveInfo ri : apps) {
            appNames.add(ri.loadLabel(pm).toString());
            appPackages.add(ri.activityInfo.packageName);
        }

        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, appNames);
        appAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        appSpinner.setAdapter(appAdapter);
    }

    private void saveGestureAssignment() {
        String gestureName = etGestureName.getText().toString().trim();
        String selectedLetter = letterSpinner.getSelectedItem().toString();
        String selectedApp = appPackages.get(appSpinner.getSelectedItemPosition());
        String appName = appSpinner.getSelectedItem().toString();

        if (gestureName.isEmpty()) {
            Toast.makeText(this, "Please enter a gesture name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save to SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // Store the mapping: LETTER -> PACKAGE_NAME
        editor.putString("LETTER_" + selectedLetter, selectedApp);

        // Store gesture name for this letter
        editor.putString("GESTURE_NAME_" + selectedLetter, gestureName);

        // Store app display name for reference
        editor.putString("APP_NAME_" + selectedLetter, appName);

        editor.apply();

        Toast.makeText(this,
                "Saved " + gestureName + ":" + selectedLetter + " → " + appSpinner.getSelectedItem(),
                Toast.LENGTH_SHORT).show();
    }

    private void setupButtons() {
        saveButton.setOnClickListener(v -> {
            String gestureName = etGestureName.getText().toString();
            String selectedLetter = (String) letterSpinner.getSelectedItem();
            int appPosition = appSpinner.getSelectedItemPosition();


            @SuppressWarnings("unchecked")
            List<String> packages = (List<String>) appSpinner.getTag();
            String selectedPackage = packages.get(appPosition);

            letterToAppMap.put(selectedLetter, selectedPackage);
            Toast.makeText(this,
                     "Saved " + gestureName + ":" + selectedLetter + " → " + appSpinner.getSelectedItem(),
                    Toast.LENGTH_SHORT).show();
        });

        TextView clearContent = findViewById(R.id.clearContent);
        clearContent.setOnClickListener(v -> clearAllInputs());

        clearButton.setOnClickListener(v -> {
            drawingView.clearCanvas();
        });

        // Button to recognize drawn letter (simplified)
        Button recognizeButton = findViewById(R.id.recognizeButton);
        recognizeButton.setOnClickListener(v -> {
            String currentLetter = (String) letterSpinner.getSelectedItem();
            onGraffitiLetterDetected(currentLetter);
        });
    }

    public void onGraffitiLetterDetected(String letter) {
        if (letterToAppMap.containsKey(letter)) {
            String packageName = letterToAppMap.get(letter);
            try {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                startActivity(launchIntent);
            } catch (Exception e) {
                Toast.makeText(this, "App not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No app assigned to " + letter, Toast.LENGTH_SHORT).show();
        }
    }

    private void clearAllInputs() {
        // Reset spinners to first item
        letterSpinner.setSelection(0);
        appSpinner.setSelection(0);

        etGestureName.setText("");

        Toast.makeText(this, "All inputs cleared", Toast.LENGTH_SHORT).show();
    }

    // Method to retrieve saved assignments (can be used from other activities)
    public static String getAssignedAppPackage(Context context, String letter) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString("LETTER_" + letter, null);
    }

    // Method to retrieve gesture name (can be used from other activities)
    public static String getGestureName(Context context, String letter) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString("GESTURE_NAME_" + letter, "");
    }

}