package com.example.gesturefinal;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class GestureSavedActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture_saved);
    }
}
