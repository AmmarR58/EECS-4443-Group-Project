package com.example.gesturefinal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * GraffitiDrawingView is a custom View that allows users to draw on the screen using touch gestures.
 * It tracks user-drawn paths and attempts to recognize letters based on their shape.
 */
public class GraffitiDrawingView extends View {

    private Paint paint;
    private Path path; // Path to store the user's drawn strokes
    private List<Float> xCoords, yCoords; // x and y coordinates

    /**
     * Constructor for initializing.
     *
     * @param context The application context.
     * @param attrs   Attribute set for XML usage.
     */
    public GraffitiDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        path = new Path();
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(8f);
        xCoords = new ArrayList<>();
        yCoords = new ArrayList<>();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPath(path, paint);
    }

    /**
     * Handles touch events for drawing paths.
     *
     * @param event touch input.
     * @return true if the event is handled, false otherwise.
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(x, y);
                xCoords.clear();
                yCoords.clear();
                xCoords.add(x);
                yCoords.add(y);
                return true;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(x, y);
                xCoords.add(x);
                yCoords.add(y);
                break;
            case MotionEvent.ACTION_UP:
                return true;
            default:
                return false;
        }

        invalidate();
        return true;
    }

    /**
     * Attempts to detect a letter from the drawn path based on geometric analysis.
     *
     * @return A detected letter (e.g., "I", "O", "U", "L") or "?" if unknown.
     */
    public String detectLetter() {
        if (xCoords.size() < 3) return null;

        // Basic shape properties
        float minX = Collections.min(xCoords);
        float maxX = Collections.max(xCoords);
        float minY = Collections.min(yCoords);
        float maxY = Collections.max(yCoords);
        float width = maxX - minX;
        float height = maxY - minY;

        // Start and end points
        float startX = xCoords.get(0);
        float startY = yCoords.get(0);
        float endX = xCoords.get(xCoords.size() - 1);
        float endY = yCoords.get(yCoords.size() - 1);

        // Direction changes
        int directionChanges = countDirectionChanges();

        if (height > 2 * width && directionChanges < 2) return "I";
        if (isLetterO(startX, startY, endX, endY, width, height)) return "O";
        if (isLetterU(startX, startY, endX, endY, width, height)) return "U";
        if (isLetterL(startX, startY, endX, endY)) return "L";
        return "?"; // Unknown letter
    }

    /**
     * Checks if the drawn path is letter 'O'.
     */
    private boolean isLetterO(float startX, float startY, float endX, float endY, float width, float height) {
        // Check if start and end points are close
        float distance = (float) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
        float size = Math.max(width, height);
        boolean isRound = Math.abs(width - height) < size * 0.3;
        return distance < size * 0.2 && isRound;
    }

    /**
     * Checks if the drawn path is letter 'U'.
     */
    private boolean isLetterU(float startX, float startY, float endX, float endY, float width, float height) {
        // Getting minY and minX
        float minX = Collections.min(xCoords);
        float minY = Collections.min(yCoords);
        // Start and end should be high points
        boolean highStart = (startY - minY) < height * 0.3;
        boolean highEnd = (endY - minY) < height * 0.3;
        // Should have a low point in the middle
        float midY = Collections.max(yCoords);
        boolean hasLowPoint = (midY - minY) > height * 0.7;
        // Start and end should be on opposite sides
        boolean oppositeSides = (startX < minX + width * 0.3) && (endX > minX + width * 0.7);

        return highStart && highEnd && hasLowPoint && oppositeSides;
    }

    /**
     * Checks if the drawn path is letter 'L'.
     */
    private boolean isLetterL(float startX, float startY, float endX, float endY) {
        // L has a vertical then horizontal stroke
        int cornerIndex = findCornerIndex();
        if (cornerIndex == -1 || cornerIndex < 3 || cornerIndex > xCoords.size() - 3) {
            return false;
        }

        // First part (vertical)
        float firstPartX = xCoords.get(cornerIndex) - startX;
        float firstPartY = yCoords.get(cornerIndex) - startY;
        boolean verticalFirst = Math.abs(firstPartY) > Math.abs(firstPartX) * 2;

        // Second part (horizontal)
        float secondPartX = endX - xCoords.get(cornerIndex);
        float secondPartY = endY - yCoords.get(cornerIndex);
        boolean horizontalSecond = Math.abs(secondPartX) > Math.abs(secondPartY) * 2;

        return verticalFirst && horizontalSecond;
    }


    private int findCornerIndex() {
        // Find the point with maximum direction change
        int cornerIndex = -1;
        float maxDirectionChange = 0;

        for (int i = 2; i < xCoords.size() - 2; i++) {
            float prevDeltaX = xCoords.get(i - 1) - xCoords.get(i - 2);
            float prevDeltaY = yCoords.get(i - 1) - yCoords.get(i - 2);
            float currDeltaX = xCoords.get(i) - xCoords.get(i - 1);
            float currDeltaY = yCoords.get(i) - yCoords.get(i - 1);

            // Calculate angle between vectors
            float dotProduct = prevDeltaX * currDeltaX + prevDeltaY * currDeltaY;
            float mag1 = (float) Math.sqrt(prevDeltaX * prevDeltaX + prevDeltaY * prevDeltaY);
            float mag2 = (float) Math.sqrt(currDeltaX * currDeltaX + currDeltaY * currDeltaY);
            float angle = (float) Math.acos(Math.min(1, Math.max(-1, dotProduct / (mag1 * mag2))));

            if (angle > maxDirectionChange) {
                maxDirectionChange = angle;
                cornerIndex = i;
            }
        }

        return maxDirectionChange > Math.PI / 4 ? cornerIndex : -1;
    }

    /**
     * Counts the number of direction changes in the drawn path.
     */
    private int countDirectionChanges() {
        int directionChanges = 0;
        float prevDeltaX = 0, prevDeltaY = 0;

        for (int i = 1; i < xCoords.size(); i++) {
            float deltaX = xCoords.get(i) - xCoords.get(i - 1);
            float deltaY = yCoords.get(i) - yCoords.get(i - 1);

            if (i > 1) {
                float dotProduct = deltaX * prevDeltaX + deltaY * prevDeltaY;
                if (dotProduct < 0) { // Direction change
                    directionChanges++;
                }
            }
            prevDeltaX = deltaX;
            prevDeltaY = deltaY;
        }
        return directionChanges;
    }

    public void clearCanvas() {
        path.reset();
        xCoords.clear();
        yCoords.clear();
        invalidate();
    }
}
