package com.example.gesturefinal;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GraffitiDrawingView extends View {

    private Paint paint;
    private Path path;
    private List<Float> xCoords, yCoords;

    public GraffitiDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        path = new Path();
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(8f);
        xCoords = new ArrayList<>();
        yCoords = new ArrayList<>();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPath(path, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(x, y);
                xCoords.clear();
                yCoords.clear();
                xCoords.add(x);
                yCoords.add(y);
                return true;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(x, y);
                xCoords.add(x);
                yCoords.add(y);
                break;
            case MotionEvent.ACTION_UP:
                return true;
            default:
                return false;
        }

        invalidate();
        return true;
    }

    public String detectLetter() {
        if (xCoords.size() < 3) return null;

        // Basic statistics
        float minX = Collections.min(xCoords);
        float maxX = Collections.max(xCoords);
        float minY = Collections.min(yCoords);
        float maxY = Collections.max(yCoords);
        float width = maxX - minX;
        float height = maxY - minY;
        float aspectRatio = width / height;

        // Start and end points
        float startX = xCoords.get(0);
        float startY = yCoords.get(0);
        float endX = xCoords.get(xCoords.size() - 1);
        float endY = yCoords.get(yCoords.size() - 1);

        // Direction changes
        int directionChanges = countDirectionChanges();

        // I - Vertical line
        if (height > 2 * width && directionChanges < 2) return "I";

        // O - Closed loop
        if (isLetterO(startX, startY, endX, endY, width, height)) return "O";

        // U - U-shape
        if (isLetterU(startX, startY, endX, endY, width, height)) return "U";

        // L - Right angle shape
        if (isLetterL(startX, startY, endX, endY)) return "L";

        if (isLetterA()) return "A"; // Added

        return "?"; // Unknown
    }

    private boolean isLetterH(float width, float height) {
        // Count direction changes between vertical and horizontal
        int verticalToHorizontal = 0;
        int horizontalToVertical = 0;

        for (int i = 2; i < xCoords.size(); i++) {
            float dx1 = xCoords.get(i - 1) - xCoords.get(i - 2);
            float dy1 = yCoords.get(i - 1) - yCoords.get(i - 2);
            float dx2 = xCoords.get(i) - xCoords.get(i - 1);
            float dy2 = yCoords.get(i) - yCoords.get(i - 1);

            boolean firstVertical = Math.abs(dy1) > Math.abs(dx1) * 2;
            boolean secondHorizontal = Math.abs(dx2) > Math.abs(dy2) * 2;
            boolean firstHorizontal = Math.abs(dx1) > Math.abs(dy1) * 2;
            boolean secondVertical = Math.abs(dy2) > Math.abs(dx2) * 2;

            if (firstVertical && secondHorizontal) verticalToHorizontal++;
            if (firstHorizontal && secondVertical) horizontalToVertical++;
        }

        // H should have at least 2 vertical-horizontal-vertical transitions
        return (verticalToHorizontal >= 2 && horizontalToVertical >= 1);
    }

    private boolean isLetterO(float startX, float startY, float endX, float endY, float width, float height) {
        // Check if start and end points are close
        float distance = (float) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
        float size = Math.max(width, height);

        // Should be somewhat circular (aspect ratio close to 1)
        boolean isRound = Math.abs(width - height) < size * 0.3;

        // Start and end should be close relative to the size
        return distance < size * 0.2 && isRound;
    }

    private boolean isLetterU(float startX, float startY, float endX, float endY, float width, float height) {
        // First we need to get minY and minX since they're not parameters
        float minX = Collections.min(xCoords);
        float minY = Collections.min(yCoords);

        // U starts high on one side, goes down, then up to other side
        float size = Math.max(width, height);

        // Start and end should be high points
        boolean highStart = (startY - minY) < height * 0.3;
        boolean highEnd = (endY - minY) < height * 0.3;

        // Should have a low point in the middle
        float midY = Collections.max(yCoords);
        boolean hasLowPoint = (midY - minY) > height * 0.7;

        // Start and end should be on opposite sides
        boolean oppositeSides = (startX < minX + width * 0.3) && (endX > minX + width * 0.7);

        return highStart && highEnd && hasLowPoint && oppositeSides;
    }

    private boolean isLetterL(float startX, float startY, float endX, float endY) {
        // L has a vertical then horizontal stroke
        int cornerIndex = findCornerIndex();
        if (cornerIndex == -1 || cornerIndex < 3 || cornerIndex > xCoords.size() - 3) {
            return false;
        }

        // First part (vertical)
        float firstPartX = xCoords.get(cornerIndex) - startX;
        float firstPartY = yCoords.get(cornerIndex) - startY;
        boolean verticalFirst = Math.abs(firstPartY) > Math.abs(firstPartX) * 2;

        // Second part (horizontal)
        float secondPartX = endX - xCoords.get(cornerIndex);
        float secondPartY = endY - yCoords.get(cornerIndex);
        boolean horizontalSecond = Math.abs(secondPartX) > Math.abs(secondPartY) * 2;

        return verticalFirst && horizontalSecond;
    }

    private int findCornerIndex() {
        // Find the point with maximum direction change
        int cornerIndex = -1;
        float maxDirectionChange = 0;

        for (int i = 2; i < xCoords.size() - 2; i++) {
            float prevDeltaX = xCoords.get(i - 1) - xCoords.get(i - 2);
            float prevDeltaY = yCoords.get(i - 1) - yCoords.get(i - 2);
            float currDeltaX = xCoords.get(i) - xCoords.get(i - 1);
            float currDeltaY = yCoords.get(i) - yCoords.get(i - 1);

            // Calculate angle between vectors
            float dotProduct = prevDeltaX * currDeltaX + prevDeltaY * currDeltaY;
            float mag1 = (float) Math.sqrt(prevDeltaX * prevDeltaX + prevDeltaY * prevDeltaY);
            float mag2 = (float) Math.sqrt(currDeltaX * currDeltaX + currDeltaY * currDeltaY);
            float angle = (float) Math.acos(Math.min(1, Math.max(-1, dotProduct / (mag1 * mag2))));

            if (angle > maxDirectionChange) {
                maxDirectionChange = angle;
                cornerIndex = i;
            }
        }

        return maxDirectionChange > Math.PI / 4 ? cornerIndex : -1;
    }

    private boolean isLetterA() {
        if (xCoords.size() < 3) return false;

        float startY = yCoords.get(0);
        float endY = yCoords.get(yCoords.size() - 1);

        float minY = Collections.min(yCoords); // Lowest point (middle of V)
        float maxY = Collections.max(yCoords); // Highest point

        int changes = countDirectionChanges();

        // Should have exactly ONE sharp turn (middle of the "V")
        if (changes != 1) return false;

        // Start and end should be HIGHER than the middle (opposite of U)
        boolean peakInMiddle = (startY > minY) && (endY > minY);

        return peakInMiddle;
    }


    private int countDirectionChanges() {
        int directionChanges = 0;
        float prevDeltaX = 0, prevDeltaY = 0;

        for (int i = 1; i < xCoords.size(); i++) {
            float deltaX = xCoords.get(i) - xCoords.get(i - 1);
            float deltaY = yCoords.get(i) - yCoords.get(i - 1);

            if (i > 1) {
                float dotProduct = deltaX * prevDeltaX + deltaY * prevDeltaY;
                if (dotProduct < 0) { // Direction change
                    directionChanges++;
                }
            }
            prevDeltaX = deltaX;
            prevDeltaY = deltaY;
        }
        return directionChanges;
    }

    public void clearCanvas() {
        path.reset();
        xCoords.clear();
        yCoords.clear();
        invalidate();
    }
}
