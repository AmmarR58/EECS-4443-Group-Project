package com.example.mygraffitilauncher;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Spinner letterSpinner;
    private Spinner appSpinner;
    private Button saveButton;
    private Button clearButton;
    private GraffitiDrawingView drawingView;
    private Map<String, String> letterToAppMap = new HashMap<>();

    // Supported Graffiti letters
    private final String[] graffitiLetters = {"A", "B", "C", "D", "E", "F", "G", "H",
            "I", "J", "K", "L", "M", "N", "O", "P",
            "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        letterSpinner = findViewById(R.id.letterSpinner);
        appSpinner = findViewById(R.id.appSpinner);
        saveButton = findViewById(R.id.saveButton);
        clearButton = findViewById(R.id.clearButton);
        drawingView = findViewById(R.id.drawingView);

        setupSpinners();
        setupButtons();
    }

    private void setupSpinners() {
        // Letter spinner
        ArrayAdapter<String> letterAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, graffitiLetters);
        letterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        letterSpinner.setAdapter(letterAdapter);

        // App spinner with installed apps
        List<String> appNames = new ArrayList<>();
        List<String> appPackages = new ArrayList<>();

        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
        for (ResolveInfo ri : apps) {
            appNames.add(ri.loadLabel(pm).toString());
            appPackages.add(ri.activityInfo.packageName);
        }

        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, appNames);
        appAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        appSpinner.setAdapter(appAdapter);

        // Store package names in tag
        appSpinner.setTag(appPackages);
    }

    private void setupButtons() {
        saveButton.setOnClickListener(v -> {
            String selectedLetter = (String) letterSpinner.getSelectedItem();
            int appPosition = appSpinner.getSelectedItemPosition();

            @SuppressWarnings("unchecked")
            List<String> packages = (List<String>) appSpinner.getTag();
            String selectedPackage = packages.get(appPosition);

            letterToAppMap.put(selectedLetter, selectedPackage);
            Toast.makeText(this,
                    "Saved: " + selectedLetter + " → " + appSpinner.getSelectedItem(),
                    Toast.LENGTH_SHORT).show();
        });

        clearButton.setOnClickListener(v -> {
            drawingView.clearCanvas();
        });

        // Button to recognize drawn letter (simplified)
        Button recognizeButton = findViewById(R.id.recognizeButton);
        recognizeButton.setOnClickListener(v -> {
            String currentLetter = (String) letterSpinner.getSelectedItem();
            onGraffitiLetterDetected(currentLetter);
        });
    }

    public void onGraffitiLetterDetected(String letter) {
        if (letterToAppMap.containsKey(letter)) {
            String packageName = letterToAppMap.get(letter);
            try {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                startActivity(launchIntent);
            } catch (Exception e) {
                Toast.makeText(this, "App not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No app assigned to " + letter, Toast.LENGTH_SHORT).show();
        }
    }
}