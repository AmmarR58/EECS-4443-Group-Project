package com.example.gesturefinal;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.widget.ArrayAdapter;

public class AddGestureActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "GesturePrefs";
    private Spinner letterSpinner, appSpinner;
    private Button saveButton, clearButton;
    private GraffitiDrawingView drawingView;
    private Map<String, String> letterToAppMap = new HashMap<>();
    private List<String> appPackages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gesture);

        letterSpinner = findViewById(R.id.letterSpinner);
        appSpinner = findViewById(R.id.appSpinner);
        saveButton = findViewById(R.id.saveButton);
        clearButton = findViewById(R.id.clearButton);
        drawingView = findViewById(R.id.drawingView);
        TextView clearContent = findViewById(R.id.clearContent);

        setupSpinners();
        setupButtons();
    }

    private void setupSpinners() {
        // Letter spinner (only 4 letters that is implemented for testing)
        String[] letters = {"I", "O", "U", "L"};

        ArrayAdapter<String> letterAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, letters);
        letterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        letterSpinner.setAdapter(letterAdapter);

        // App spinner with installed apps
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
        List<String> appNames = new ArrayList<>();

        for (ResolveInfo ri : apps) {
            appNames.add(ri.loadLabel(pm).toString());
            appPackages.add(ri.activityInfo.packageName);
        }

        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, appNames);
        appAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        appSpinner.setAdapter(appAdapter);
    }

    private void setupButtons() {
        saveButton.setOnClickListener(v -> saveGestureAssignment());

        clearButton.setOnClickListener(v -> drawingView.clearCanvas());

        Button recognizeButton = findViewById(R.id.recognizeButton);
        recognizeButton.setOnClickListener(v -> {
            String detectedLetter = drawingView.detectLetter();
            if (detectedLetter != null) {
                onGraffitiLetterDetected(detectedLetter);
            } else {
                Toast.makeText(this, "No recognizable letter drawn", Toast.LENGTH_SHORT).show();
            }
        });

        TextView clearContent = findViewById(R.id.clearContent);
        clearContent.setOnClickListener(v -> clearAllInputs());
    }

    private void saveGestureAssignment() {
        String selectedLetter = letterSpinner.getSelectedItem().toString();
        int appPosition = appSpinner.getSelectedItemPosition();

        if (appPosition < 0 || appPosition >= appPackages.size()) {
            Toast.makeText(this, "Invalid app selection", Toast.LENGTH_SHORT).show();
            return;
        }

        String selectedApp = appPackages.get(appPosition);

        // Save in SharedPreferences (override existing)
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("LETTER_" + selectedLetter, selectedApp);
        editor.apply();

        // Update local map
        letterToAppMap.put(selectedLetter, selectedApp);

        Toast.makeText(this, "Assigned: " + selectedLetter + " → " + appSpinner.getSelectedItem(), Toast.LENGTH_SHORT).show();
    }

    public void onGraffitiLetterDetected(String letter) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String packageName = prefs.getString("LETTER_" + letter, null);

        if (packageName != null) {
            try {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (launchIntent != null) {
                    startActivity(launchIntent);
                    Toast.makeText(this, "App found for " + letter, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "App not found for" + letter, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error launching app", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No app assigned to " + letter, Toast.LENGTH_SHORT).show();
        }
    }

    private void clearAllInputs() {
        letterSpinner.setSelection(0);
        appSpinner.setSelection(0);
        drawingView.clearCanvas();

//        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
//        prefs.edit().clear().apply();

        Toast.makeText(this, "All inputs cleared", Toast.LENGTH_SHORT).show();
    }
}
