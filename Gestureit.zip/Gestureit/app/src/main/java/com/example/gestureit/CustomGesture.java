package com.example.gestureit;

import android.gesture.Gesture;
import android.os.Parcel;
import android.os.Parcelable;

public class CustomGesture implements Parcelable {
    private String name;
    private String action;
    private Gesture gesturePattern;

    public CustomGesture(String name, String action, Gesture gesturePattern) {
        this.name = name;
        this.action = action;
        this.gesturePattern = gesturePattern;
    }

    protected CustomGesture(Parcel in) {
        name = in.readString();
        action = in.readString();
        gesturePattern = in.readParcelable(Gesture.class.getClassLoader());
    }

    public static final Creator<CustomGesture> CREATOR = new Creator<CustomGesture>() {
        @Override
        public CustomGesture createFromParcel(Parcel in) {
            return new CustomGesture(in);
        }

        @Override
        public CustomGesture[] newArray(int size) {
            return new CustomGesture[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(action);
        dest.writeParcelable(gesturePattern, flags);
    }

    public String getName() {
        return name;
    }

    public String getAction() {
        return action;
    }

    public Gesture getGesturePattern() {
        return gesturePattern;
    }
}