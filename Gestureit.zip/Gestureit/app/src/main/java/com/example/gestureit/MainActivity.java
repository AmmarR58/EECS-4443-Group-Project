package com.example.gestureit;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Delay for 2 seconds and then start WelcomeActivity
        new Handler().postDelayed(() -> {
            startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
            finish();
        }, 2000); // 2-second delay
    }
}