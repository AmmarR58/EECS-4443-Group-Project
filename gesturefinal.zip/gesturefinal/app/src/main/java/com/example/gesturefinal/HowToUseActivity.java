package com.example.gesturefinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HowToUseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_use);

        TextView tvCreatingGestures = findViewById(R.id.tvCreatingGestures);
        TextView tvManagingGestures = findViewById(R.id.tvManagingGestures);
        Button btnWatchTutorials = findViewById(R.id.btnWatchTutorials);
        Button btnReadFAQs = findViewById(R.id.btnReadFAQs);

        tvCreatingGestures.setOnClickListener(v -> {
            startActivity(new Intent(HowToUseActivity.this, AddGestureActivity.class));
        });

        tvManagingGestures.setOnClickListener(v -> {
            startActivity(new Intent(HowToUseActivity.this, GestureSavedActivity.class));
        });

        btnWatchTutorials.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/shorts/ALGlxz2wqUw?feature=share"));
            startActivity(intent);
        });

        btnReadFAQs.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/AmmarR58/EECS-4443-Group-Project"));
            startActivity(intent);
        });
    }
}